#!/usr/bin/perl

# ./adjusttbatch.pl < results.txt > r2.txt
# results is correct format with n, and ,1
# i made everything lower case....
# and not even a space at the bottom or you get ,,,,

use strict;
use warnings;

my %rename = (
    'bob' => 'bobt',
    'jim'     => 'jimb',
    'bill' => 'billmcav',
    'ken' => 'kens',
    'rando'  => 'rando400',
    'joel' => 'joelk',
    'mike'     => 'mikeg',
    'grant' => 'grantw',
    'sherm' => 'sherman',


);

while (<>) {

    chomp;

    my @f = split /,/;

    # Fields 1-4 contain the player names
    for my $i (1..4) {

        my $name = $f[$i];

        # Preserve T1 prefix if present
        my $prefix = '';
        if ($name =~ s/^(T1)//i) {
            $prefix = $1;
        }

        if (exists $rename{$name}) {
            $f[$i] = $prefix . $rename{$name};
        }
        else {
            $f[$i] = $prefix . $name;
        }
    }

    print join(",", @f), "\n";
}
