#!/bin/bash

# this takes all players from /prod and pulls out 
# private group Z8
# removes the Z8 from those players
# adds on the sql top so it becomes a better csv.
# the make script uses --all because in private groups we
# want players that don't play.   
# upload the html when done

#
# ./make_Z8.pl --all
# includes 0 games played players
#

grep Z8 ../prod/players > tempplayers
grep -vi -f bluelist.list tempplayers > tempplayers1
sed 's/^Z8//' tempplayers1 > tempplayers2
cat sqltopper tempplayers2 > players.csv

./make_Z8.pl 
