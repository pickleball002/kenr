#!/usr/bin/perl
#
# kcs Dec 2025
# V1 variables + gender field (9th)
#
# 40 divisors.   search for '40'.  adjust up to lessen all numbers
# 33 games before halving result
# 55 ratio   teams favored by .75 or more get good bump
# 51 games for all total sets RelFlag (reliability)

use strict;
use warnings;
use POSIX qw(strftime);

my $mxplayers_file = 'mxplayers';
my $backup_file  = 'backupmxplayers';
my $log_file     = 'mxlogging';

# ---------------------------------------------------------
# Logging setup
# ---------------------------------------------------------
open(my $logfh, ">>", $log_file) or die "Cannot open log file '$log_file': $!";

sub logprint {
    my ($msg) = @_;
    print $msg;
    print $logfh $msg;
}

# ---------------------------------------------------------
# Timestamp
# ---------------------------------------------------------
my $timestamp = strftime("%Y-%m-%d %H:%M:%S", localtime);
logprint("\n=== Script Run: $timestamp ===\n");

# ---------------------------------------------------------
# Grand Prix Flag Prompt
# ---------------------------------------------------------
logprint("\nIs this a GrandPrix event? (Y/N): ");
chomp(my $gp_input = <STDIN>);

my $grandprix = 0;

if ($gp_input =~ /^y(es)?$/i) {
    $grandprix = 1;
} elsif ($gp_input =~ /^n(o)?$/i) {
    $grandprix = 0;
} else {
    logprint("Unclear answer. Defaulting to NO.\n");
    $grandprix = 0;
}

logprint("GrandPrix flag set to: $grandprix\n");


logprint("\n=== Loading Players File ===\n");

my $loaded_count = 0;
# ---------------------------------------------------------
# Read mxplayers file
# ---------------------------------------------------------
open(my $pfh, "<", $mxplayers_file) or die "Cannot open '$mxplayers_file': $!";
my %mxplayers;

while (<$pfh>) {
    chomp;
	$loaded_count++;
    my @cols = split /,/;

    my ($name, $rank, $games, $won, $lost, $pct, $dev, $orig, $gender, $age);

    if (@cols == 3) {
        ($name,$rank,$games) = @cols;
        ($won,$lost,$pct,$dev,$orig,$gender,$age) = (0,0,0,0,$rank,"U",19);
    }
    elsif (@cols == 8) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig) = @cols;
        ($gender,$age) = ("U",19);
    }
    elsif (@cols == 9) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig,$gender) = @cols;
        $age = 19;
    }
    elsif (@cols == 10) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig,$gender,$age) = @cols;
        $age ||= 19;
    }
    else {
        die "Invalid line in mxplayers file: $_\n";
    }


    my $key = lc $name;

    if (exists $mxplayers{$key}) {
        if ($games > $mxplayers{$key}->{games}) {
            logprint("Duplicate found for $name — keeping entry with MORE games\n");
            $mxplayers{$key} = {
                name=>$name, rank=>$rank+0, games=>$games+0,
                won=>$won+0, lost=>$lost+0, pct=>$pct+0,
                dev=>$dev+0, orig=>$orig+0, gender=>$gender,
		age=>$age+0
            };
        } else {
            logprint("Duplicate found for $name — discarding entry\n");
        }
        next;
    }

    $mxplayers{$key} = {
        name=>$name, rank=>$rank+0, games=>$games+0,
        won=>$won+0, lost=>$lost+0, pct=>$pct+0,
        dev=>$dev+0, orig=>$orig+0, gender=>$gender,
	age=>$age+0
    };

#    logprint("Loaded: $name  rank=$rank  games=$games  won=$won lost=$lost gender=$gender\n");
}
close($pfh);
logprint("Loaded $loaded_count players\n");

# Resolve Brian Bryan

sub normalize_name {
    my ($name) = @_;
    $name = lc $name;

    # Normalize common vowel variations
    $name =~ s/ie/y/g;     # brianie → bryany
    $name =~ s/ai/ay/g;    # kaitlyn → kaytlyn
    $name =~ tr/iy/y/;     # i and y treated same

    return $name;
}


# ---------------------------------------------------------
# Resolve name (exact or fuzzy)
# ---------------------------------------------------------

sub resolve_name {
    my ($input) = @_;
    my $key = lc $input;

    # Exact match?
    return $key if exists $mxplayers{$key};

    my @candidates;

    # Prefix fuzzy match (3 chars)
if (length($key) >= 3) {

    my $norm_key = normalize_name($key);
    my $prefix = substr($norm_key, 0, 3);

    foreach my $p (keys %mxplayers) {

        my $norm_p = normalize_name($p);

        push @candidates, $mxplayers{$p}->{name}
            if substr($norm_p, 0, 3) eq $prefix;
    }
}


    # If no prefix matches, try substring matches anywhere
if (!@candidates && length($key) >= 3) {

    my $norm_key = normalize_name($key);

    foreach my $p (keys %mxplayers) {

        my $norm_p = normalize_name($p);

        push @candidates, $mxplayers{$p}->{name}
            if index($norm_p, $norm_key) != -1;
    }
}


    # Still no matches
    return undef unless @candidates;

    # One match → auto-use
    if (@candidates == 1) {
        logprint("No exact match for '$input'. Using close match: $candidates[0]\n");
        return lc $candidates[0];
    }

    # Multiple matches → prompt
    logprint("\nNo exact match for '$input'. Possible matches:\n");
    for my $i (0 .. $#candidates) {
        logprint("  ".($i+1).") $candidates[$i]\n");
    }

    logprint("Select a number: ");
    chomp(my $choice = <STDIN>);

    if ($choice =~ /^\d+$/ && $choice >= 1 && $choice <= @candidates) {
        return lc $candidates[$choice-1];
    }

    logprint("Invalid choice.\n");
    return undef;
}



# ---------------------------------------------------------
# Backup file
# ---------------------------------------------------------
logprint("\n=== Creating Backup File: $backup_file ===\n");
open(my $bkp, ">", $backup_file) or die "Cannot write '$backup_file': $!";
open($pfh, "<", $mxplayers_file);
print $bkp $_ for (<$pfh>);
close($pfh);
close($bkp);

# ---------------------------------------------------------
# Input
# ---------------------------------------------------------
logprint("\n=== First Pair Input ===\n");
logprint("Enter first name: ");
chomp(my $n1in=<STDIN>);
my $n1=resolve_name($n1in)||die;

logprint("Enter second name: ");
chomp(my $n2in=<STDIN>);
my $n2=resolve_name($n2in)||die;

my $rank1=$mxplayers{$n1}->{rank};
my $rank2=$mxplayers{$n2}->{rank};

logprint("Player 1: $mxplayers{$n1}->{name}, rank = $rank1\n");
logprint("Player 2: $mxplayers{$n2}->{name}, rank = $rank2\n");

logprint("Winner Pair Total Rank = ".($rank1+$rank2)."\n");

logprint("\n=== Second Pair Input ===\n");
logprint("Enter third name: ");
chomp(my $n3in=<STDIN>);
my $n3=resolve_name($n3in)||die;

logprint("Enter fourth name: ");
chomp(my $n4in=<STDIN>);
my $n4=resolve_name($n4in)||die;

my $rank3=$mxplayers{$n3}->{rank};
my $rank4=$mxplayers{$n4}->{rank};

logprint("Player 3: $mxplayers{$n3}->{name}, rank = $rank3\n");
logprint("Player 4: $mxplayers{$n4}->{name}, rank = $rank4\n");
logprint("Opponent Pair Total Rank = ".($rank3+$rank4)."\n");

# ---------------------------------------------------------
# Reliability Flag (All Players Experienced)
# ---------------------------------------------------------
my $relflag = 0;

if (
    $mxplayers{$n1}->{games} > 51 &&
    $mxplayers{$n2}->{games} > 51 &&
    $mxplayers{$n3}->{games} > 51 &&
    $mxplayers{$n4}->{games} > 51
) {
    $relflag = 1;
}

logprint(
    "Games played: " .
    "$n1=$mxplayers{$n1}->{games}, " .
    "$n2=$mxplayers{$n2}->{games}, " .
    "$n3=$mxplayers{$n3}->{games}, " .
    "$n4=$mxplayers{$n4}->{games} . " .
    "RelFlag=$relflag\n"
);


# ---------------------------------------------------------
# Mixed Match Detection
# ---------------------------------------------------------
my $g1 = lc $mxplayers{$n1}->{gender};
my $g2 = lc $mxplayers{$n2}->{gender};
my $g3 = lc $mxplayers{$n3}->{gender};
my $g4 = lc $mxplayers{$n4}->{gender};

my $pair1_mixed = (($g1 eq "m" && $g2 eq "f") || ($g1 eq "f" && $g2 eq "m"));
my $pair2_mixed = (($g3 eq "m" && $g4 eq "f") || ($g3 eq "f" && $g4 eq "m"));

my $mixedmatch = ($pair1_mixed && $pair2_mixed) ? 1 : 0;

#if ($mixedmatch) {
#    logprint("\n*** MIXED MATCH DETECTED ***\n");
#} else {
#    logprint("\n(Not a mixed match)\n");
#}

if ($mixedmatch) {
    logprint("\n*** MIXED MATCH DETECTED ***\n");
} else {
    logprint("\nOpponents were NOT mixed — aborting! No rank updates applied.\n");
    exit;   # ← stops script immediately
}

# ---------------------------------------------------------
# Ratio calc
# ---------------------------------------------------------
logprint("\n=== Ratio Calculation ===\n");

my $winner_rank=$rank1 + $rank2;
my $opponent_rank=$rank3 + $rank4;

my $ratio = $winner_rank / $opponent_rank;

if ($winner_rank >= $opponent_rank + 0.55) { $ratio += 0.56; }
elsif ($winner_rank <= $opponent_rank - 0.55) { $ratio -= 0.56; }

if ($ratio != 1) {
    $ratio = 1/$ratio;
    logprint("Ratio inverted → $ratio\n");
} else {
    logprint("Ratio = $ratio\n");
}

# ---------------------------------------------------------
# Games divisor + final adjusted
# ---------------------------------------------------------
logprint("\nWas this 1, 2, or 3 games? ");
chomp(my $gamesplayed=<STDIN>);

# ---------------------------------------------------------
# Games divisor + final adjusted (GrandPrix aware) 'old 40'
# ---------------------------------------------------------

my ($gp_one, $gp_two, $gp_three);

if ($grandprix) {
    # Grand Prix mode → smaller divisors
    $gp_one   = 29;
    $gp_two   = 13;
    $gp_three = 26;
} else {
    # Standard mode
    $gp_one   = 58;
    $gp_two   = 27;
    $gp_three = 52;
}


# ---------------------------------------------------------
# Reliability Flag adjustment
# ---------------------------------------------------------
if ($relflag) {
    logprint("relflag=1 → established-player penalty removed\n");
}


my ($winner_divisor, $loser_divisor);

if ($gamesplayed == 1) {
    $winner_divisor = $gp_one;
    $loser_divisor  = $gp_one;
}
elsif ($gamesplayed == 2) {
    $winner_divisor = $gp_two;
    $loser_divisor  = $gp_two;
}
elsif ($gamesplayed == 3) {
    $winner_divisor = $gp_three;
    $loser_divisor  = $gp_one;
}
else {
    die "Invalid gamesplayed value: $gamesplayed\n";
}

my $winner_adj = $ratio / $winner_divisor;
my $loser_adj  = $ratio / $loser_divisor;

#my $final_adjusted_value = $ratio / $divisor;

logprint("GrandPrix=$grandprix | Games=$gamesplayed | Divisors=$winner_adj,$loser_adj\n");
#logprint("Final adjusted value = $final_adjusted_value\n");

#logprint("GrandPrix flag = $grandprix → divisor used = $divisor\n");
#logprint("Final adjusted value = $final_adjusted_value\n");



#logprint("Final adjusted value = $final_adjusted_value\n");




# ---------------------------------------------------------
# Rank update helper
# ---------------------------------------------------------
sub update_rank {
    my ($key,$val)=@_;

    my $adj = $val;
    my $games = $mxplayers{$key}->{games};

    # Established-player penalty
    if (!$relflag && $games >= 33) {
        $adj /= 2;
        logprint("$key: established-player reliability reduction -> adj=$adj\n");
    }

    # Future black-hole rules
    if ($mxplayers{$key}->{rank} >= 5.5) {
        $adj /= 2;
    }

    if ($mxplayers{$key}->{rank} >= 6.0) {
        $adj /= 2;
    }

    $mxplayers{$key}->{rank} += $adj;

logprint(
    "DEBUG $key: games=$mxplayers{$key}->{games} ".
    "rank=$mxplayers{$key}->{rank} ".
    "incoming=$val\n"
);

}

update_rank($n1,  $winner_adj);
update_rank($n2,  $winner_adj);
update_rank($n3, -$loser_adj);
update_rank($n4, -$loser_adj);


# ---------------------------------------------------------
# Games played
# ---------------------------------------------------------
$mxplayers{$_}->{games}+=$gamesplayed for ($n1,$n2,$n3,$n4);


# ---------------------------------------------------------
# Replay recap (logging file ONLY)
# ---------------------------------------------------------
my ($date_only) = split / /, $timestamp;

print $logfh join(" ",
    "replayrecap",
    $date_only,
    $mxplayers{$n1}->{name},
    $mxplayers{$n2}->{name},
    "/",
    $mxplayers{$n3}->{name},
    $mxplayers{$n4}->{name},
    "games=$gamesplayed"
) . "\n";

# ---------------------------------------------------------
# Games Won/Lost
# ---------------------------------------------------------
if ($gamesplayed == 1) {
    $mxplayers{$n1}->{won} += 1; $mxplayers{$n2}->{won} += 1;
    $mxplayers{$n3}->{lost} += 1; $mxplayers{$n4}->{lost} += 1;
}
elsif ($gamesplayed == 2) {
    $mxplayers{$n1}->{won} += 2; $mxplayers{$n2}->{won} += 2;
    $mxplayers{$n3}->{lost} += 2; $mxplayers{$n4}->{lost} += 2;
}
elsif ($gamesplayed == 3) {
    $mxplayers{$n1}->{won} += 2; $mxplayers{$n1}->{lost} += 1;
    $mxplayers{$n2}->{won} += 2; $mxplayers{$n2}->{lost} += 1;

    $mxplayers{$n3}->{won} += 1; $mxplayers{$n3}->{lost} += 2;
    $mxplayers{$n4}->{won} += 1; $mxplayers{$n4}->{lost} += 2;
}

# ---------------------------------------------------------
# pct & deviation
# ---------------------------------------------------------
foreach my $p (keys %mxplayers) {
    my $w = $mxplayers{$p}->{won};
    my $l = $mxplayers{$p}->{lost};

    if ($w + $l > 0) {
        $mxplayers{$p}->{pct} = $w / ($w + $l);
    } else {
        $mxplayers{$p}->{pct} = 0;
    }

    $mxplayers{$p}->{dev} = $mxplayers{$p}->{rank} - $mxplayers{$p}->{orig};
}

# ---------------------------------------------------------
# Write mxplayers file
# ---------------------------------------------------------
logprint("\n=== Writing Updated Players File ===\n");

open(my $out, ">", $mxplayers_file) or die;

my @with_games = grep { $mxplayers{$_}->{games} > 0 } keys %mxplayers;
my @zero_games = grep { $mxplayers{$_}->{games} == 0 } keys %mxplayers;

@with_games = sort { $mxplayers{$b}->{rank} <=> $mxplayers{$a}->{rank} } @with_games;
@zero_games = sort { lc($mxplayers{$a}->{name}) cmp lc($mxplayers{$b}->{name}) } @zero_games;

foreach my $p (@with_games, @zero_games) {
    print $out join(",",
        ucfirst($mxplayers{$p}->{name}),
        sprintf("%.5f",$mxplayers{$p}->{rank}),
        $mxplayers{$p}->{games},
        $mxplayers{$p}->{won},
        $mxplayers{$p}->{lost},
        sprintf("%.5f",$mxplayers{$p}->{pct}),
        sprintf("%.5f",$mxplayers{$p}->{dev}),
        sprintf("%.5f",$mxplayers{$p}->{orig}),
        $mxplayers{$p}->{gender},
	$mxplayers{$p}->{age}
    )."\n";
}

close($out);

logprint("\n=== Update Complete ===\n");
logprint("Version 3.0 — batch processing\n");

# ---------------------------------------------------------
# Write winningpercentage file
# ---------------------------------------------------------
logprint("\n=== Writing mxwinningpercentage File ===\n");

open(my $wp, ">", "mxwinningpercentage") or die "Cannot write mxwinningpercentage: $!";

my @wp_with_games = grep { $mxplayers{$_}->{games} > 0 } keys %mxplayers;
my @wp_zero_games = grep { $mxplayers{$_}->{games} == 0 } keys %mxplayers;

@wp_with_games = sort { $mxplayers{$b}->{pct} <=> $mxplayers{$a}->{pct} } @wp_with_games;
@wp_zero_games = sort { lc($mxplayers{$a}->{name}) cmp lc($mxplayers{$b}->{name}) } @wp_zero_games;

foreach my $p (@wp_with_games, @wp_zero_games) {
    print $wp join(",",
        ucfirst($mxplayers{$p}->{name}),
        sprintf("%.5f",$mxplayers{$p}->{rank}),
        $mxplayers{$p}->{games},
        $mxplayers{$p}->{won},
        $mxplayers{$p}->{lost},
        sprintf("%.5f",$mxplayers{$p}->{pct}),
        sprintf("%.5f",$mxplayers{$p}->{dev}),
        sprintf("%.5f",$mxplayers{$p}->{orig}),
        $mxplayers{$p}->{gender},
	$mxplayers{$p}->{age}
    )."\n";
}
close($wp);

# ---------------------------------------------------------
# Write deviation file
# ---------------------------------------------------------
logprint("\n=== Writing deviation File ===\n");

open(my $dv, ">", "mxdeviation") or die "Cannot write mxdeviation: $!";

my @dv_with_games = grep { $mxplayers{$_}->{games} > 0 } keys %mxplayers;
my @dv_zero_games = grep { $mxplayers{$_}->{games} == 0 } keys %mxplayers;

@dv_with_games = sort { $mxplayers{$b}->{dev} <=> $mxplayers{$a}->{dev} } @dv_with_games;
@dv_zero_games = sort { lc($mxplayers{$a}->{name}) cmp lc($mxplayers{$b}->{name}) } @dv_zero_games;

foreach my $p (@dv_with_games, @dv_zero_games) {
    print $dv join(",",
        ucfirst($mxplayers{$p}->{name}),
        sprintf("%.5f",$mxplayers{$p}->{rank}),
        $mxplayers{$p}->{games},
        $mxplayers{$p}->{won},
        $mxplayers{$p}->{lost},
        sprintf("%.5f",$mxplayers{$p}->{pct}),
        sprintf("%.5f",$mxplayers{$p}->{dev}),
        sprintf("%.5f",$mxplayers{$p}->{orig}),
        $mxplayers{$p}->{gender},
	$mxplayers{$p}->{age}
    )."\n";
}
close($dv);

close($logfh);
