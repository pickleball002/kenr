#!/bin/bash

# this takes all players from /prod and pulls out 
# private group T1
# removes the T1 from those players
# adds on the sql top so it becomes a better csv.
# the make script uses --all because in private groups we
# want players that don't play.   
# upload the html when done

grep T1 ../prod/players > tempplayers
grep -vi -f bluelist.list tempplayers > tempplayers1
sed 's/^T1//' tempplayers1 > tempplayers2
cat sqltopper tempplayers2 > players.csv

./make_T1.pl --all
