#!/usr/bin/perl
#
# kcs Dec 2025
# V1 variables + gender field (9th)
#
# 40 / 80 divisors
# 33 games before halving result
# 55 ratio   teams favored by .75 or more get good bump
# reversed!   .55 now gets you .75
# tweaked!  .55 now gets your .56
# 51 games for all total sets RelFlag (reliability)

use strict;
use warnings;
use POSIX qw(strftime);

my $players_file = 'singlesplayers';
my $backup_file  = 'sbackupplayers';
my $log_file     = 'slogging';

# ---------------------------------------------------------
# Logging setup
# ---------------------------------------------------------
open(my $logfh, ">>", $log_file) or die "Cannot open log file '$log_file': $!";

sub logprint {
    my ($msg) = @_;
    print $msg;
    print $logfh $msg;
}

# ---------------------------------------------------------
# Timestamp
# ---------------------------------------------------------
my $timestamp = strftime("%Y-%m-%d %H:%M:%S", localtime);
logprint("\n=== Script Run: $timestamp ===\n");

logprint("\n=== Loading Players File ===\n");

# ---------------------------------------------------------
# Grand Prix Flag Prompt
# ---------------------------------------------------------
logprint("\nIs this a GrandPrix event? (Y/N): ");
chomp(my $gp_input = <STDIN>);

my $grandprix = 0;

if ($gp_input =~ /^y(es)?$/i) {
    $grandprix = 1;
} elsif ($gp_input =~ /^n(o)?$/i) {
    $grandprix = 0;
} else {
    logprint("Unclear answer. Defaulting to NO.\n");
    $grandprix = 0;
}

logprint("GrandPrix flag set to: $grandprix\n");


# ---------------------------------------------------------
# Read players file
# ---------------------------------------------------------
open(my $pfh, "<", $players_file) or die "Cannot open '$players_file': $!";
my %players;

while (<$pfh>) {
    chomp;
    my @cols = split /,/;

    my ($name, $rank, $games, $won, $lost, $pct, $dev, $orig, $gender);

    if (@cols == 3) {
        ($name,$rank,$games) = @cols;
        ($won,$lost,$pct,$dev,$orig,$gender) = (0,0,0,0,$rank,"U");
    }
    elsif (@cols == 8) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig) = @cols;
        $gender = "U";
    }
    elsif (@cols == 9) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig,$gender) = @cols;
    }
    else {
        die "Invalid line in players file: $_\n";
    }

    my $key = lc $name;

    if (exists $players{$key}) {
        if ($games > $players{$key}->{games}) {
            logprint("Duplicate found for $name — keeping entry with MORE games\n");
            $players{$key} = {
                name=>$name, rank=>$rank+0, games=>$games+0,
                won=>$won+0, lost=>$lost+0, pct=>$pct+0,
                dev=>$dev+0, orig=>$orig+0, gender=>$gender
            };
        } else {
            logprint("Duplicate found for $name — discarding entry\n");
        }
        next;
    }

    $players{$key} = {
        name=>$name, rank=>$rank+0, games=>$games+0,
        won=>$won+0, lost=>$lost+0, pct=>$pct+0,
        dev=>$dev+0, orig=>$orig+0, gender=>$gender
    };

    logprint("Loaded: $name  rank=$rank  games=$games  won=$won lost=$lost gender=$gender\n");
}
close($pfh);

# Resolve Brian Bryan

sub normalize_name {
    my ($name) = @_;
    $name = lc $name;

    # Normalize common vowel variations
    $name =~ s/ie/y/g;     # brianie → bryany
    $name =~ s/ai/ay/g;    # kaitlyn → kaytlyn
    $name =~ tr/iy/y/;     # i and y treated same

    return $name;
}


# ---------------------------------------------------------
# Resolve name (exact or fuzzy)
# ---------------------------------------------------------
# New resolve name

sub resolve_name {
    my ($input) = @_;
    my $key = lc $input;

    # Exact match?
    return $key if exists $players{$key};

    my @candidates;
# old prefix

    # Prefix fuzzy match (3 chars)
#    if (length($key) >= 3) {
#        my $prefix = substr($key, 0, 3);
#        foreach my $p (keys %players) {
#            push @candidates, $players{$p}->{name} if substr($p,0,3) eq $prefix;
#        }
#    }

# new prefix block

# Prefix fuzzy match (3 chars, phonetic aware)
if (length($key) >= 3) {

    my $norm_key = normalize_name($key);
    my $prefix = substr($norm_key, 0, 3);

    foreach my $p (keys %players) {

        my $norm_p = normalize_name($p);

        push @candidates, $players{$p}->{name}
            if substr($norm_p, 0, 3) eq $prefix;
    }
}

# new candidates

# If no prefix matches, try substring matches anywhere (phonetic aware)
if (!@candidates && length($key) >= 3) {

    my $norm_key = normalize_name($key);

    foreach my $p (keys %players) {

        my $norm_p = normalize_name($p);

        push @candidates, $players{$p}->{name}
            if index($norm_p, $norm_key) != -1;
    }
}


   # Still no matches
    return undef unless @candidates;

    # One match → auto-use
    if (@candidates == 1) {
        logprint("No exact match for '$input'. Using close match: $candidates[0]\n");
        return lc $candidates[0];
    }

    # Multiple matches → prompt
    logprint("\nNo exact match for '$input'. Possible matches:\n");
    for my $i (0 .. $#candidates) {
        logprint("  ".($i+1).") $candidates[$i]\n");
    }

    logprint("Select a number: ");
    chomp(my $choice = <STDIN>);

    if ($choice =~ /^\d+$/ && $choice >= 1 && $choice <= @candidates) {
        return lc $candidates[$choice-1];
    }

    logprint("Invalid choice.\n");
    return undef;
}




# ---------------------------------------------------------
# Backup file
# ---------------------------------------------------------
logprint("\n=== Creating Backup File: $backup_file ===\n");
open(my $bkp, ">", $backup_file) or die "Cannot write '$backup_file': $!";
open($pfh, "<", $players_file);
print $bkp $_ for (<$pfh>);
close($pfh);
close($bkp);

# ---------------------------------------------------------
# Input
# ---------------------------------------------------------
logprint("\n=== First Pair Input ===\n");
logprint("Enter first name: ");
chomp(my $n1in=<STDIN>);
my $n1=resolve_name($n1in)||die;

logprint("Enter second name: ");
chomp(my $n2in=<STDIN>);
my $n2=resolve_name($n2in)||die;

my $rank1=$players{$n1}->{rank};
my $rank2=$players{$n2}->{rank};

logprint("Player 1: $players{$n1}->{name}, rank = $rank1\n");
logprint("Player 2: $players{$n2}->{name}, rank = $rank2\n");

logprint("Winner Pair Total Rank = ".($rank1+$rank2)."\n");

logprint("\n=== Second Pair Input ===\n");
logprint("Enter third name: ");
chomp(my $n3in=<STDIN>);
my $n3=resolve_name($n3in)||die;

logprint("Enter fourth name: ");
chomp(my $n4in=<STDIN>);
my $n4=resolve_name($n4in)||die;

my $rank3=$players{$n3}->{rank};
my $rank4=$players{$n4}->{rank};

logprint("Player 3: $players{$n3}->{name}, rank = $rank3\n");
logprint("Player 4: $players{$n4}->{name}, rank = $rank4\n");
logprint("Opponent Pair Total Rank = ".($rank3+$rank4)."\n");

# set a flag if there over 101 games played between
# the teams.   this is increased reliability


# ---------------------------------------------------------
# Reliability Flag (All Players Experienced)
# ---------------------------------------------------------
my $relflag = 0;

if (
    $players{$n1}->{games} > 51 &&
    $players{$n2}->{games} > 51 &&
    $players{$n3}->{games} > 51 &&
    $players{$n4}->{games} > 51
) {
    $relflag = 1;
}

logprint(
    "Games played: " .
    "$n1=$players{$n1}->{games}, " .
    "$n2=$players{$n2}->{games}, " .
    "$n3=$players{$n3}->{games}, " .
    "$n4=$players{$n4}->{games} . " .
    "RelFlag=$relflag\n"
);

# ---------------------------------------------------------
# Mixed Match Detection
# ---------------------------------------------------------
my $g1 = lc $players{$n1}->{gender};
my $g2 = lc $players{$n2}->{gender};
my $g3 = lc $players{$n3}->{gender};
my $g4 = lc $players{$n4}->{gender};

my $pair1_mixed = (($g1 eq "m" && $g2 eq "f") || ($g1 eq "f" && $g2 eq "m"));
my $pair2_mixed = (($g3 eq "m" && $g4 eq "f") || ($g3 eq "f" && $g4 eq "m"));

my $mixedmatch = ($pair1_mixed && $pair2_mixed) ? 1 : 0;

if ($mixedmatch) {
    logprint("\n*** MIXED MATCH DETECTED - RUN mxscript.pl now!! ***\n");
} else {
    logprint("\n(Not a mixed match)\n");
}

# ---------------------------------------------------------
# Mens Match Detection
# ---------------------------------------------------------

my $pair1_mens = (($g1 eq "m" && $g2 eq "m") && ($g1 eq "m" && $g2 eq "m"));
my $pair2_mens = (($g3 eq "m" && $g4 eq "m") && ($g3 eq "m" && $g4 eq "m"));
    
my $mensmatch = ($pair1_mens && $pair2_mens) ? 1 : 0;

if ($mensmatch) {
    logprint("\n*** MENS MATCH DETECTED - RUN mdscript.pl now!! ***\n");
} else {
    logprint("\n(Not a mens match)\n");
}

# ---------------------------------------------------------
# Womens Match Detection
# ---------------------------------------------------------
my $pair1_womens = (($g1 eq "f" && $g2 eq "f") && ($g1 eq "f" && $g2 eq "f"));
my $pair2_womens = (($g3 eq "f" && $g4 eq "f") && ($g3 eq "f" && $g4 eq "f"));
    
my $womensmatch = ($pair1_womens && $pair2_womens) ? 1 : 0;

if ($womensmatch) {
    logprint("\n*** WOMENS MATCH DETECTED - RUN wdscript.pl now!! ***\n");
} else {
    logprint("\n(Not a womens match)\n");
}



# ---------------------------------------------------------
# Ratio calc
# ---------------------------------------------------------
logprint("\n=== Ratio Calculation ===\n");

my $winner_rank=$rank1 + $rank2;
my $opponent_rank=$rank3 + $rank4;

my $ratio = $winner_rank / $opponent_rank;

if ($winner_rank >= $opponent_rank + 0.55) { $ratio += 0.56; }
elsif ($winner_rank <= $opponent_rank - 0.55) { $ratio -= 0.56; }

if ($ratio != 1) {
    $ratio = 1/$ratio;
    logprint("Ratio inverted → $ratio\n");
} else {
    logprint("Ratio = $ratio\n");
}

# ---------------------------------------------------------
# Games divisor + final adjusted  'old 40'
# ---------------------------------------------------------
logprint("\nWas this 1, 2, or 3 games? ");
chomp(my $gamesplayed=<STDIN>);


# ---------------------------------------------------------
# Games divisor + final adjusted (GrandPrix aware) 'old 40'
# ---------------------------------------------------------

my ($gp_one, $gp_two, $gp_three);

if ($grandprix) {
    # Grand Prix mode → smaller divisors
    $gp_one   = 106;
    $gp_two   = 54;
    $gp_three = 104;
} else {
    # Standard mode
    $gp_one   = 232;
    $gp_two   = 108;
    $gp_three = 208;
}


# ---------------------------------------------------------
# Reliability Flag adjustment
# ---------------------------------------------------------
if ($relflag) {   # RelFlag == 1
    $gp_one   = int($gp_one   / 2 + 0.5);
    $gp_two   = int($gp_two   / 2 + 0.5);
    $gp_three = int($gp_three / 2 + 0.5);

    logprint(
        "relflag=1 → Divisors halved: ".
        "gp1=$gp_one gp2=$gp_two gp3=$gp_three\n"
    );
}

my $divisor;

if ($gamesplayed == 1) {
    $divisor = $gp_one;
}
elsif ($gamesplayed == 2) {
    $divisor = $gp_two;
}
elsif ($gamesplayed == 3) {
    $divisor = $gp_three;
}
else {
    die "Invalid gamesplayed value: $gamesplayed\n";
}

my $final_adjusted_value = $ratio / $divisor;

logprint("GrandPrix=$grandprix | Games=$gamesplayed | Divisor=$divisor\n");
logprint("Final adjusted value = $final_adjusted_value\n");

#logprint("GrandPrix flag = $grandprix → divisor used = $divisor\n");
#logprint("Final adjusted value = $final_adjusted_value\n");


# ---------------------------------------------------------
# Rank update helper
# ---------------------------------------------------------
sub update_rank {
    my ($key,$val)=@_;
    my $adj=$val;
    $adj*=2 if $players{$key}->{games} < 33;
    $players{$key}->{rank}+=$adj;
}

update_rank($n1, $final_adjusted_value);
update_rank($n2, $final_adjusted_value);
update_rank($n3,-$final_adjusted_value);
update_rank($n4,-$final_adjusted_value);

# ---------------------------------------------------------
# Games played
# ---------------------------------------------------------
$players{$_}->{games}+=$gamesplayed for ($n1,$n2,$n3,$n4);

#print $logfh "replayrecap $players{$n1}->{name},$players{$n2}->{name} / $players{$n3}->{name},$players{$n4}->{name} games=$gamesplayed\n";

# ---------------------------------------------------------
# Replay recap (logging file ONLY)
# ---------------------------------------------------------
my ($date_only) = split / /, $timestamp;

print $logfh join(" ",
    "replayrecap",
    $date_only,
    $players{$n1}->{name},
    $players{$n2}->{name},
    "/",
    $players{$n3}->{name},
    $players{$n4}->{name},
    "games=$gamesplayed"
) . "\n";


# ---------------------------------------------------------
# Games Won/Lost
# ---------------------------------------------------------
if ($gamesplayed == 1) {
    $players{$n1}->{won} += 1; $players{$n2}->{won} += 1;
    $players{$n3}->{lost} += 1; $players{$n4}->{lost} += 1;
}
elsif ($gamesplayed == 2) {
    $players{$n1}->{won} += 2; $players{$n2}->{won} += 2;
    $players{$n3}->{lost} += 2; $players{$n4}->{lost} += 2;
}
elsif ($gamesplayed == 3) {
    $players{$n1}->{won} += 2; $players{$n1}->{lost} += 1;
    $players{$n2}->{won} += 2; $players{$n2}->{lost} += 1;

    $players{$n3}->{won} += 1; $players{$n3}->{lost} += 2;
    $players{$n4}->{won} += 1; $players{$n4}->{lost} += 2;
}

# ---------------------------------------------------------
# pct & deviation
# ---------------------------------------------------------
foreach my $p (keys %players) {
    my $w = $players{$p}->{won};
    my $l = $players{$p}->{lost};

    if ($w + $l > 0) {
        $players{$p}->{pct} = $w / ($w + $l);
    } else {
        $players{$p}->{pct} = 0;
    }

    $players{$p}->{dev} = $players{$p}->{rank} - $players{$p}->{orig};
}

# ---------------------------------------------------------
# Write players file
# ---------------------------------------------------------
logprint("\n=== Writing Updated Players File ===\n");

open(my $out, ">", $players_file) or die;

my @with_games = grep { $players{$_}->{games} > 0 } keys %players;
my @zero_games = grep { $players{$_}->{games} == 0 } keys %players;

@with_games = sort { $players{$b}->{rank} <=> $players{$a}->{rank} } @with_games;
@zero_games = sort { lc($players{$a}->{name}) cmp lc($players{$b}->{name}) } @zero_games;

foreach my $p (@with_games, @zero_games) {
    print $out join(",",
        ucfirst($players{$p}->{name}),
        sprintf("%.5f",$players{$p}->{rank}),
        $players{$p}->{games},
        $players{$p}->{won},
        $players{$p}->{lost},
        sprintf("%.5f",$players{$p}->{pct}),
        sprintf("%.5f",$players{$p}->{dev}),
        sprintf("%.5f",$players{$p}->{orig}),
        $players{$p}->{gender}
    )."\n";
}

close($out);

logprint("\n=== Update Complete ===\n");
logprint("Version 3.0 — batch processing\n");

# ---------------------------------------------------------
# Write winningpercentage file
# ---------------------------------------------------------
logprint("\n=== Writing winningpercentage File ===\n");

open(my $wp, ">", "winningpercentage") or die "Cannot write winningpercentage: $!";

my @wp_with_games = grep { $players{$_}->{games} > 0 } keys %players;
my @wp_zero_games = grep { $players{$_}->{games} == 0 } keys %players;

@wp_with_games = sort { $players{$b}->{pct} <=> $players{$a}->{pct} } @wp_with_games;
@wp_zero_games = sort { lc($players{$a}->{name}) cmp lc($players{$b}->{name}) } @wp_zero_games;

foreach my $p (@wp_with_games, @wp_zero_games) {
    print $wp join(",",
        ucfirst($players{$p}->{name}),
        sprintf("%.5f",$players{$p}->{rank}),
        $players{$p}->{games},
        $players{$p}->{won},
        $players{$p}->{lost},
        sprintf("%.5f",$players{$p}->{pct}),
        sprintf("%.5f",$players{$p}->{dev}),
        sprintf("%.5f",$players{$p}->{orig}),
        $players{$p}->{gender}
    )."\n";
}
close($wp);

# ---------------------------------------------------------
# Write deviation file
# ---------------------------------------------------------
logprint("\n=== Writing deviation File ===\n");

open(my $dv, ">", "sdeviation") or die "Cannot write deviation: $!";

my @dv_with_games = grep { $players{$_}->{games} > 0 } keys %players;
my @dv_zero_games = grep { $players{$_}->{games} == 0 } keys %players;

@dv_with_games = sort { $players{$b}->{dev} <=> $players{$a}->{dev} } @dv_with_games;
@dv_zero_games = sort { lc($players{$a}->{name}) cmp lc($players{$b}->{name}) } @dv_zero_games;

foreach my $p (@dv_with_games, @dv_zero_games) {
    print $dv join(",",
        ucfirst($players{$p}->{name}),
        sprintf("%.5f",$players{$p}->{rank}),
        $players{$p}->{games},
        $players{$p}->{won},
        $players{$p}->{lost},
        sprintf("%.5f",$players{$p}->{pct}),
        sprintf("%.5f",$players{$p}->{dev}),
        sprintf("%.5f",$players{$p}->{orig}),
        $players{$p}->{gender}
    )."\n";
}
close($dv);

close($logfh);
