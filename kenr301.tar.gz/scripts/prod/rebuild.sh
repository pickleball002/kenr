#!/bin/bash

echo "=== REBUILD PROCESS STARTING ==="

# when you rebuild the system, nothing should be in results.txt
# all previous matches in prevresults.txt
# update your origplayers file in /prod
# The results file will be restored from the first cp
# sure run distro next to push results.txt everywhere
cp -v prevresults.txt results.txt
cp origplayers players
rm prevresults.txt
rm logging

# --- MENS ---
echo "Resetting mens directory"
(
    cd ../mens || exit
    cp -v origplayers mdplayers
    rm -f *log*
)

# --- WOMENS ---
echo "Resetting womens directory"
(
    cd ../womens || exit
    cp -v origplayers wdplayers
    rm -f *log*
)

# --- MIXED ---
echo "Resetting mixed directory"
(
    cd ../mixed || exit
    cp -v origplayers mxplayers
    rm -f *log*
)

# --- SANDBOX ---
echo "Resetting sandbox directory"
(
    cd ../sandbox || exit
    cp -v origplayers players
    rm -f *log*
)

echo "=== REBUILD COMPLETE ==="
