#!/bin/bash

RESULTS="results.txt"
PLAYERS="origplayers"

if [ ! -f "$RESULTS" ]; then
    echo "ERROR: $RESULTS not found"
    exit 1
fi

if [ ! -f "$PLAYERS" ]; then
    echo "ERROR: $PLAYERS not found"
    exit 1
fi

DIRS=(
    "/home/ken/Documents/pickleball/scripts/mens"
    "/home/ken/Documents/pickleball/scripts/womens"
    "/home/ken/Documents/pickleball/scripts/mixed"
    "/home/ken/Documents/pickleball/scripts/sandbox"
)

	if [ -f results.txt ]; then
cat results.txt >> prevresults.txt
echo "Appended results.txt to prevresults.txt"
	else
echo "results.txt not found — skipping append"
	fi


for dir in "${DIRS[@]}"
do
    if [ -d "$dir" ]; then
        echo "Copying to $dir"
        cp "$RESULTS" "$dir/"
        cp "$PLAYERS" "$dir/"
    else
        echo "WARNING: Directory $dir does not exist"
    fi
done

echo "Done."
