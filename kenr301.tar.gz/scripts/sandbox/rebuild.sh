#!/bin/bash

echo "=== REBUILD PROCESS STARTING ==="

# Restore results file
cp -v prevresults.txt results.txt

# --- MENS ---
echo "Resetting mens directory"
(
    cd ../mens || exit
    cp -v ../origplayers mdplayers
    rm -f *log*
)

# --- WOMENS ---
echo "Resetting womens directory"
(
    cd ../womens || exit
    cp -v ../origplayers wdplayers
    rm -f *log*
)

# --- MIXED ---
echo "Resetting mixed directory"
(
    cd ../mixed || exit
    cp -v ../origplayers mxplayers
    rm -f *log*
)

# --- SANDBOX ---
echo "Resetting sandbox directory"
(
    cd ../sandbox || exit
    cp -v ../origplayers origplayers
    rm -f *log*
)

echo "=== REBUILD COMPLETE ==="
