#!/bin/bash

SCRIPT="./thescript.pl"

while IFS=',' read -r gp n1 n2 n3 n4 games
do
    echo "======================================"
    echo "Processing: $gp,$n1,$n2,$n3,$n4,$games"

    printf "%s\n%s\n%s\n%s\n%s\n%s\n" \
        "$gp" "$n1" "$n2" "$n3" "$n4" "$games" \
        | $SCRIPT

done < "$1"

