#!/bin/bash

echo "=== REBUILD PROCESS STARTING ==="

# when you rebuild the system, nothing should be in results.txt
# all previous matches in prevresults.txt
# update your origplayers file in /prod
# The results file will be restored from the first cp
# sure run distro next to push results.txt everywhere
cp -v prevresults.txt goodresults.txt
cp -v prevresults.txt results.txt
cp origplayers players
rm prevresults.txt
rm logging

# --- MENS ---
echo "Resetting mens directory"
(
    cp -v origplayers ../mens/mdplayers
    rm -f ../mens/*log*
)

# --- WOMENS ---
echo "Resetting womens directory"
(
    cp -v origplayers ../womens/wdplayers
    rm -f ../womens/*log*
)

# --- MIXED ---
echo "Resetting mixed directory"
(
    cp -v origplayers ../mixed/mxplayers
    rm -f ../mixed/*log*
)

# --- SANDBOX ---
echo "Resetting sandbox directory"
(
    cp -v origplayers ../sandbox/players
    rm -f ../sandbox/*log*
)

# --- MENS65 ---
echo "Resetting mens directory"
(
    cp -v origplayers ../md65/md65players
    rm -f ../md65/*log*
)


echo "=== REBUILD COMPLETE ==="
