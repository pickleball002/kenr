#!/bin/bash

SCRIPT="./playerone.pl"


while IFS=',' read -r gp n1 n2 n3 n4 games
do
    printf "%s\n%s\n%s\n%s\n%s\n%s\n" \
        "$gp" "$n1" "$n2" "$n3" "$n4" "$games" \
        | $SCRIPT

    if [ $? -ne 0 ]; then
	echo -e "\nBATCHINPUTFAILURE: $gp,$n1,$n2,$n3,$n4,$games" >> slogging
    fi

done < "$1"

