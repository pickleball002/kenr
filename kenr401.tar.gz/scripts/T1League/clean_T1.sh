#!/bin/bash
# take deviation output, clean the blacklist
# save as csv for the make script
# run after superdistro
# private group, this uses 'players'.  If levels are different use 'deviation'.

grep T1 ../prod/players > tempplayers
cat sqltopper tempplayers > players.csv

./make_T1.pl
