#!/bin/bash
# take deviation output, clean the blacklist
# save as csv for the make script
# run after superdistro

grep -vi -f blacklist.list mddeviation > tempcsv

cat sqltopper tempcsv > mddeviation.csv

./make_md.pl
