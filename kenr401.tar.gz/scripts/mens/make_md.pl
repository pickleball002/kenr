#!/usr/bin/perl

use strict;
use warnings;

my $csvfile  = "mddeviation.csv";
my $htmlfile = "mens_doubles.html";

my $include_inactive_players = 0;

use POSIX qw(strftime);

my $last_updated =
    strftime("%B %d, %Y %I:%M %p", localtime);



# --all includes those with 0 games played.  good for private groups.

$include_inactive_players = 1
    if grep { $_ eq '--all' } @ARGV;


open(my $IN, "<", $csvfile) or die "Cannot open $csvfile\n";

my @players;

<$IN>;    # skip header

while (<$IN>) {
    chomp;

    my @f = split /,/;

push @players, {
    name     => $f[0],
    rating   => $f[1],
    played   => $f[2],
    won      => $f[3],
    lost     => $f[4],
    pct      => $f[5],
    change   => $f[6],
    original => $f[7],
    gender   => $f[8],
    age      => $f[9]
};

}

close $IN;


# sort by change.  make this rating if you want.  sorter!

@players = sort {

    # active players first
    ($b->{played} > 0) <=> ($a->{played} > 0)

    ||

    # then highest change
    $b->{change} <=> $a->{change}

} @players;


open(my $OUT, ">", $htmlfile)
    or die "Cannot create $htmlfile\n";

print $OUT <<'HTML';
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Mens Doubles</title>

<style>

body{
    font-family:Arial,sans-serif;
    background:#f4f6f9;
    margin:0;
}

.banner{
    background:#0b3d91;
    color:white;
    text-align:center;
    padding:25px;
}

.container{
    max-width:1100px;
    margin:20px auto;
    padding:10px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

th{
    background:#0b3d91;
    color:white;
    padding:12px;
}

td{
    padding:10px;
    text-align:center;
    border-bottom:1px solid #ddd;
}

td.player{
    text-align:left;
    font-weight:bold;
}

.inactive{
    background:#fafafa;
    color:#777;
}

.positive{
    color:green;
    font-weight:bold;
}

.negative{
    color:red;
    font-weight:bold;
}

.footer{
    text-align:center;
    color:#777;
    font-size:0.9rem;
    margin:25px 0;
}


</style>
</head>

<body>

<div class="banner">
<h1>Mens Doubles</h1>
<p>Player Ratings & Match Results</p>
</div>

<div class="container">

<table>

<thead>
<tr>
<th>Player</th>
<th>Rating</th>
<th>Played</th>
<th>Won</th>
<th>Lost</th>
<th>Win %</th>
<th>Original</th>
<th>Change</th>
</tr>
</thead>

<tbody>
HTML

foreach my $p (@players)
{

next if (!$include_inactive_players && $p->{played} == 0);

    my $inactive =
        ($p->{played} == 0) ? ' class="inactive"' : '';

    my $change_class = '';

    if ($p->{change} > 0)
    {
        $change_class = 'positive';
    }
    elsif ($p->{change} < 0)
    {
        $change_class = 'negative';
    }

    my $pct = sprintf("%.1f", $p->{pct} * 100);

print $OUT qq|
<tr$inactive>
<td class="player">$p->{name}</td>
<td>@{[sprintf("%.5f",$p->{rating})]}</td>
<td>$p->{played}</td>
<td>$p->{won}</td>
<td>$p->{lost}</td>
<td>${pct}%</td>
<td>@{[sprintf("%.5f",$p->{original})]}</td>
<td class="$change_class">@{[sprintf("%.5f",$p->{change})]}</td>
</tr>
|;
}

print $OUT <<HTML;
</tbody>
</table>

</div>

<div class="footer">
    Last updated $last_updated
</div>

</body>
</html>
HTML


close $OUT;

print "Created mdstandings.html\n";
