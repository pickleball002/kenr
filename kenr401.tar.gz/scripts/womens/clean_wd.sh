#!/bin/bash
# take deviation output, clean the blacklist
# save as csv for the make script
# run after superdistro

grep -vi -f blacklist.list wddeviation > tempcsv

cat sqltopper tempcsv > wddeviation.csv

./make_wd.pl
