#!/bin/bash
# take deviation output, clean the blacklist
# save as csv for the make script
# run after superdistro

grep -vi -f blacklist.list mxdeviation > tempcsv

cat sqltopper tempcsv > mxdeviation.csv

./make_mx.pl
