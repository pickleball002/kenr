#!/bin/bash
# Each time you want to enter data in batch mode first thing you check is results.txt
# those should have been last results.  They should be at the bottom of prevresults.txt
# if they are you can delete items from results and enter your new data.
# run 'distro'.  It keeps origplayers fresh, and puts new results.txt in each directory.
# when you run distro, it puts this results.txt as a tail on prevresults.

RESULTS="results.txt"
PLAYERS="origplayers"

if [ ! -f "$RESULTS" ]; then
    echo "ERROR: $RESULTS not found"
    exit 1
fi

if [ ! -f "$PLAYERS" ]; then
    echo "ERROR: $PLAYERS not found"
    exit 1
fi

DIRS=(
    "/home/ken/Documents/pickleball/scripts/mens"
    "/home/ken/Documents/pickleball/scripts/womens"
    "/home/ken/Documents/pickleball/scripts/mixed"
    "/home/ken/Documents/pickleball/scripts/md65"
    "/home/ken/Documents/pickleball/scripts/sandbox"
)

	if [ -f results.txt ]; then
cat results.txt >> prevresults.txt
echo "Appended results.txt to prevresults.txt"
	else
echo "results.txt not found — skipping append"
	fi

# update the prod, then do all new directories
	./batch.sh results.txt


for dir in "${DIRS[@]}"
do
    if [ -d "$dir" ]; then
        echo "Copying to $dir"
        cp "$RESULTS" "$dir/"
        cp "$PLAYERS" "$dir/"
	cd $dir
	./batch.sh results.txt
	cd ../prod    
    else
        echo "WARNING: Directory $dir does not exist"
    fi
done

echo "Done."
