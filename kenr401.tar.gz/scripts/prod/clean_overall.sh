#!/bin/bash
# take deviation output, clean the blacklist
# save as csv for the make script
# run after superdistro

grep -vi -f blacklist.list deviation > tempcsv

cat sqltopper tempcsv > deviation.csv

./make_overall.pl
