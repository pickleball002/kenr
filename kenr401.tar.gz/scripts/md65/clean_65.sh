#!/bin/bash
# take deviation output, clean the blacklist
# save as csv for the make script
# run after superdistro

grep -vi -f blacklist.list md65deviation > tempcsv

cat sqltopper tempcsv > md65deviation.csv

./make_65.pl
