#!/usr/bin/perl
#
# kcs Dec 2025
# V1 variables + gender field (9th)
# variable 'age' added 10 field
#
# 40 divisors.   search for '40'.  adjust up to lessen all numbers
# 33 games before halving result
# 55 ratio   teams favored by .75 or more get good bump
# 51 games for all total sets RelFlag (reliability)
#
# to create any 'age' division search for the word 'gender'.
# the actual change is 'Age Detection'
###########################################################
# template for age division creation
###########################################################




use strict;
use warnings;
use POSIX qw(strftime);

my $md65players_file = 'md65players';
my $backup_file  = 'backupmd65players';
my $log_file     = 'md65logging';

# ---------------------------------------------------------
# Logging setup
# ---------------------------------------------------------
open(my $logfh, ">>", $log_file) or die "Cannot open log file '$log_file': $!";

sub logprint {
    my ($msg) = @_;
    print $msg;
    print $logfh $msg;
}

# ---------------------------------------------------------
# Timestamp
# ---------------------------------------------------------
my $timestamp = strftime("%Y-%m-%d %H:%M:%S", localtime);
logprint("\n=== Script Run: $timestamp ===\n");

# ---------------------------------------------------------
# Grand Prix Flag Prompt
# ---------------------------------------------------------
logprint("\nIs this a GrandPrix event? (Y/N): ");
chomp(my $gp_input = <STDIN>);

my $grandprix = 0;

if ($gp_input =~ /^y(es)?$/i) {
    $grandprix = 1;
} elsif ($gp_input =~ /^n(o)?$/i) {
    $grandprix = 0;
} else {
    logprint("Unclear answer. Defaulting to NO.\n");
    $grandprix = 0;
}

logprint("GrandPrix flag set to: $grandprix\n");


logprint("\n=== Loading Players File ===\n");

# ---------------------------------------------------------
# Read md65players file
# ---------------------------------------------------------
open(my $pfh, "<", $md65players_file) or die "Cannot open '$md65players_file': $!";
my %md65players;

while (<$pfh>) {
    chomp;
    my @cols = split /,/;

    my ($name, $rank, $games, $won, $lost, $pct, $dev, $orig, $gender, $age);

    if (@cols == 3) {
        ($name,$rank,$games) = @cols;
        ($won,$lost,$pct,$dev,$orig,$gender,$age) = (0,0,0,0,$rank,"U",19);
    }
    elsif (@cols == 8) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig) = @cols;
        ($gender,$age) = ("U",19);
    }
    elsif (@cols == 9) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig,$gender) = @cols;
        $age = 19;
    }
    elsif (@cols == 10) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig,$gender,$age) = @cols;
        $age ||= 19;
    }
    else {
        die "Invalid line in md65players file: $_\n";
    }


    my $key = lc $name;

    if (exists $md65players{$key}) {
        if ($games > $md65players{$key}->{games}) {
            logprint("Duplicate found for $name — keeping entry with MORE games\n");
            $md65players{$key} = {
                name=>$name, rank=>$rank+0, games=>$games+0,
                won=>$won+0, lost=>$lost+0, pct=>$pct+0,
                dev=>$dev+0, orig=>$orig+0, gender=>$gender,
                age=>$age+0
            };
        } else { 
            logprint("Duplicate found for $name — discarding entry\n");
        }
        next;
    }

    $md65players{$key} = {
        name=>$name, rank=>$rank+0, games=>$games+0,
        won=>$won+0, lost=>$lost+0, pct=>$pct+0,
        dev=>$dev+0, orig=>$orig+0, gender=>$gender,
        age=>$age+0
    };



    logprint("Loaded: $name  rank=$rank  games=$games  won=$won lost=$lost gender=$gender\n");
}
close($pfh);

# Resolve Brian Bryan

sub normalize_name {
    my ($name) = @_;
    $name = lc $name;

    # Normalize common vowel variations
    $name =~ s/ie/y/g;     # brianie → bryany
    $name =~ s/ai/ay/g;    # kaitlyn → kaytlyn
    $name =~ tr/iy/y/;     # i and y treated same

    return $name;
}


# ---------------------------------------------------------
# Resolve name (exact or fuzzy)
# ---------------------------------------------------------

sub resolve_name {
    my ($input) = @_;
    my $key = lc $input;

    # Exact match?
    return $key if exists $md65players{$key};

    my @candidates;

# new prefix block

# Prefix fuzzy match (3 chars, phonetic aware)
if (length($key) >= 3) {

    my $norm_key = normalize_name($key);
    my $prefix = substr($norm_key, 0, 3);

    foreach my $p (keys %md65players) {

        my $norm_p = normalize_name($p);

        push @candidates, $md65players{$p}->{name}
            if substr($norm_p, 0, 3) eq $prefix;
    }
}

# new candidates

# If no prefix matches, try substring matches anywhere (phonetic aware)
if (!@candidates && length($key) >= 3) {

    my $norm_key = normalize_name($key);

    foreach my $p (keys %md65players) {

        my $norm_p = normalize_name($p);

        push @candidates, $md65players{$p}->{name}
            if index($norm_p, $norm_key) != -1;
    }
}


    # Still no matches
    return undef unless @candidates;

    # One match → auto-use
    if (@candidates == 1) {
        logprint("No exact match for '$input'. Using close match: $candidates[0]\n");
        return lc $candidates[0];
    }

    # Multiple matches → prompt
    logprint("\nNo exact match for '$input'. Possible matches:\n");
    for my $i (0 .. $#candidates) {
        logprint("  ".($i+1).") $candidates[$i]\n");
    }

    logprint("Select a number: ");
    chomp(my $choice = <STDIN>);

    if ($choice =~ /^\d+$/ && $choice >= 1 && $choice <= @candidates) {
        return lc $candidates[$choice-1];
    }

    logprint("Invalid choice.\n");
    return undef;
}



# ---------------------------------------------------------
# Backup file
# ---------------------------------------------------------
logprint("\n=== Creating Backup File: $backup_file ===\n");
open(my $bkp, ">", $backup_file) or die "Cannot write '$backup_file': $!";
open($pfh, "<", $md65players_file);
print $bkp $_ for (<$pfh>);
close($pfh);
close($bkp);

# ---------------------------------------------------------
# Input
# ---------------------------------------------------------
logprint("\n=== First Pair Input ===\n");
logprint("Enter first name: ");
chomp(my $n1in=<STDIN>);
my $n1=resolve_name($n1in)||die;

logprint("Enter second name: ");
chomp(my $n2in=<STDIN>);
my $n2=resolve_name($n2in)||die;

my $rank1=$md65players{$n1}->{rank};
my $rank2=$md65players{$n2}->{rank};

logprint("Player 1: $md65players{$n1}->{name}, rank = $rank1\n");
logprint("Player 2: $md65players{$n2}->{name}, rank = $rank2\n");

logprint("Winner Pair Total Rank = ".($rank1+$rank2)."\n");

logprint("\n=== Second Pair Input ===\n");
logprint("Enter third name: ");
chomp(my $n3in=<STDIN>);
my $n3=resolve_name($n3in)||die;

logprint("Enter fourth name: ");
chomp(my $n4in=<STDIN>);
my $n4=resolve_name($n4in)||die;

my $rank3=$md65players{$n3}->{rank};
my $rank4=$md65players{$n4}->{rank};

logprint("Player 3: $md65players{$n3}->{name}, rank = $rank3\n");
logprint("Player 4: $md65players{$n4}->{name}, rank = $rank4\n");
logprint("Opponent Pair Total Rank = ".($rank3+$rank4)."\n");



# ---------------------------------------------------------
# Reliability Flag (All Players Experienced)
# ---------------------------------------------------------
my $relflag = 0;

if (
    $md65players{$n1}->{games} > 51 &&
    $md65players{$n2}->{games} > 51 &&
    $md65players{$n3}->{games} > 51 &&
    $md65players{$n4}->{games} > 51
) {
    $relflag = 1;
}

logprint(
    "Games played: " .
    "$n1=$md65players{$n1}->{games}, " .
    "$n2=$md65players{$n2}->{games}, " .
    "$n3=$md65players{$n3}->{games}, " .
    "$n4=$md65players{$n4}->{games} . " .
    "RelFlag=$relflag\n"
);

# ---------------------------------------------------------
# Mens Match Detection
# ---------------------------------------------------------
my $g1 = lc $md65players{$n1}->{gender};
my $g2 = lc $md65players{$n2}->{gender};
my $g3 = lc $md65players{$n3}->{gender};
my $g4 = lc $md65players{$n4}->{gender};

my $pair1_mens = (($g1 eq "m" && $g2 eq "m") && ($g1 eq "m" && $g2 eq "m"));
my $pair2_mens = (($g3 eq "m" && $g4 eq "m")  && ($g3 eq "m" && $g4 eq "m"));

my $mensmatch = ($pair1_mens && $pair2_mens) ? 1 : 0;

if ($mensmatch) {
    logprint("\n*** MENS MATCH DETECTED ***\n");
} else {
    logprint("\nOpponents were NOT mens — aborting! No rank updates applied.\n");
    exit;   # ← stops script immediately
}

# ---------------------------------------------------------
# Senior 65+ Match Detection or Age Detection
# ---------------------------------------------------------
my $a1 = $md65players{$n1}->{age};
my $a2 = $md65players{$n2}->{age};
my $a3 = $md65players{$n3}->{age};
my $a4 = $md65players{$n4}->{age};

my $pair1_age = ($a1 >= 65 && $a2 >= 65) ;
my $pair2_age = ($a3 >= 65 && $a4 >= 65) ;

my $agematch = ($pair1_age && $pair2_age) ? 1 : 0;

if ($agematch) {
    logprint("\n*** Age MATCH DETECTED ***\n");
} else {
    logprint("\nOpponents did not meet the age requirements no updates applied.\n");
    exit;   # ← stops script immediately 
}


# ---------------------------------------------------------
# Ratio calc
# ---------------------------------------------------------
logprint("\n=== Ratio Calculation ===\n");

my $winner_rank=$rank1 + $rank2;
my $opponent_rank=$rank3 + $rank4;

my $ratio = $winner_rank / $opponent_rank;

if ($winner_rank >= $opponent_rank + 0.55) { $ratio += 0.56; }
elsif ($winner_rank <= $opponent_rank - 0.55) { $ratio -= 0.56; }

if ($ratio != 1) {
    $ratio = 1/$ratio;
    logprint("Ratio inverted → $ratio\n");
} else {
    logprint("Ratio = $ratio\n");
}

# ---------------------------------------------------------
# Games divisor + final adjusted
# ---------------------------------------------------------
logprint("\nWas this 1, 2, or 3 games? ");
chomp(my $gamesplayed=<STDIN>);

# grandprix doubles with 20 over 40
#my $divisor = ($gamesplayed==2)?40:80;
#my $final_adjusted_value = $ratio/$divisor;

# ---------------------------------------------------------
# Games divisor + final adjusted (GrandPrix aware) 'old 40'
# ---------------------------------------------------------

my ($gp_one, $gp_two, $gp_three);

if ($grandprix) {
    # Grand Prix mode → smaller divisors
    $gp_one   = 58;
    $gp_two   = 27;
    $gp_three = 52;
} else {
    # Standard mode
    $gp_one   = 116;
    $gp_two   = 54;
    $gp_three = 104;
}
my $divisor;

if ($gamesplayed == 1) {
    $divisor = $gp_one;
}
elsif ($gamesplayed == 2) {
    $divisor = $gp_two;
}
elsif ($gamesplayed == 3) {
    $divisor = $gp_three;
}
else {
    die "Invalid gamesplayed value: $gamesplayed\n";
}

my $final_adjusted_value = $ratio / $divisor;

logprint("GrandPrix=$grandprix | Games=$gamesplayed | Divisor=$divisor\n");
logprint("Final adjusted value = $final_adjusted_value\n");


# ---------------------------------------------------------
# Rank update helper
# ---------------------------------------------------------
sub update_rank {
    my ($key,$val)=@_;
    my $adj=$val;
    $adj*=2 if $md65players{$key}->{games} < 30;
    $md65players{$key}->{rank}+=$adj;
}

update_rank($n1, $final_adjusted_value);
update_rank($n2, $final_adjusted_value);
update_rank($n3,-$final_adjusted_value);
update_rank($n4,-$final_adjusted_value);

# ---------------------------------------------------------
# Games played
# ---------------------------------------------------------
$md65players{$_}->{games}+=$gamesplayed for ($n1,$n2,$n3,$n4);


# ---------------------------------------------------------
# Replay recap (logging file ONLY)
# ---------------------------------------------------------
my ($date_only) = split / /, $timestamp;

print $logfh join(" ",
    "replayrecap",
    $date_only,
    $md65players{$n1}->{name},
    $md65players{$n2}->{name},
    "/",
    $md65players{$n3}->{name},
    $md65players{$n4}->{name},
    "games=$gamesplayed"
) . "\n";

# ---------------------------------------------------------
# Games Won/Lost
# ---------------------------------------------------------
if ($gamesplayed == 1) {
    $md65players{$n1}->{won} += 1; $md65players{$n2}->{won} += 1;
    $md65players{$n3}->{lost} += 1; $md65players{$n4}->{lost} += 1;
}
elsif ($gamesplayed == 2) {
    $md65players{$n1}->{won} += 2; $md65players{$n2}->{won} += 2;
    $md65players{$n3}->{lost} += 2; $md65players{$n4}->{lost} += 2;
}
elsif ($gamesplayed == 3) {
    $md65players{$n1}->{won} += 2; $md65players{$n1}->{lost} += 1;
    $md65players{$n2}->{won} += 2; $md65players{$n2}->{lost} += 1;

    $md65players{$n3}->{won} += 1; $md65players{$n3}->{lost} += 2;
    $md65players{$n4}->{won} += 1; $md65players{$n4}->{lost} += 2;
}

# ---------------------------------------------------------
# pct & deviation
# ---------------------------------------------------------
foreach my $p (keys %md65players) {
    my $w = $md65players{$p}->{won};
    my $l = $md65players{$p}->{lost};

    if ($w + $l > 0) {
        $md65players{$p}->{pct} = $w / ($w + $l);
    } else {
        $md65players{$p}->{pct} = 0;
    }

    $md65players{$p}->{dev} = $md65players{$p}->{rank} - $md65players{$p}->{orig};
}

# ---------------------------------------------------------
# Write md65players file
# ---------------------------------------------------------
logprint("\n=== Writing Updated Players File ===\n");

open(my $out, ">", $md65players_file) or die;

my @with_games = grep { $md65players{$_}->{games} > 0 } keys %md65players;
my @zero_games = grep { $md65players{$_}->{games} == 0 } keys %md65players;

@with_games = sort { $md65players{$b}->{rank} <=> $md65players{$a}->{rank} } @with_games;
@zero_games = sort { lc($md65players{$a}->{name}) cmp lc($md65players{$b}->{name}) } @zero_games;

foreach my $p (@with_games, @zero_games) {
    print $out join(",",
        ucfirst($md65players{$p}->{name}),
        sprintf("%.5f",$md65players{$p}->{rank}),
        $md65players{$p}->{games},
        $md65players{$p}->{won},
        $md65players{$p}->{lost},
        sprintf("%.5f",$md65players{$p}->{pct}),
        sprintf("%.5f",$md65players{$p}->{dev}),
        sprintf("%.5f",$md65players{$p}->{orig}),
        $md65players{$p}->{gender},
	$md65players{$p}->{age}
    )."\n";
}

close($out);

logprint("\n=== Update Complete ===\n");
logprint("Version 3.0 — batch processing\n");

# ---------------------------------------------------------
# Write winningpercentage file
# ---------------------------------------------------------
logprint("\n=== Writing md65winningpercentage File ===\n");

open(my $wp, ">", "md65winningpercentage") or die "Cannot write md65winningpercentage: $!";

my @wp_with_games = grep { $md65players{$_}->{games} > 0 } keys %md65players;
my @wp_zero_games = grep { $md65players{$_}->{games} == 0 } keys %md65players;

@wp_with_games = sort { $md65players{$b}->{pct} <=> $md65players{$a}->{pct} } @wp_with_games;
@wp_zero_games = sort { lc($md65players{$a}->{name}) cmp lc($md65players{$b}->{name}) } @wp_zero_games;

foreach my $p (@wp_with_games, @wp_zero_games) {
    print $wp join(",",
        ucfirst($md65players{$p}->{name}),
        sprintf("%.5f",$md65players{$p}->{rank}),
        $md65players{$p}->{games},
        $md65players{$p}->{won},
        $md65players{$p}->{lost},
        sprintf("%.5f",$md65players{$p}->{pct}),
        sprintf("%.5f",$md65players{$p}->{dev}),
        sprintf("%.5f",$md65players{$p}->{orig}),
        $md65players{$p}->{gender},
	$md65players{$p}->{age}
    )."\n";
}
close($wp);

# ---------------------------------------------------------
# Write deviation file
# ---------------------------------------------------------
logprint("\n=== Writing deviation File ===\n");

open(my $dv, ">", "md65deviation") or die "Cannot write md65deviation: $!";

my @dv_with_games = grep { $md65players{$_}->{games} > 0 } keys %md65players;
my @dv_zero_games = grep { $md65players{$_}->{games} == 0 } keys %md65players;

@dv_with_games = sort { $md65players{$b}->{dev} <=> $md65players{$a}->{dev} } @dv_with_games;
@dv_zero_games = sort { lc($md65players{$a}->{name}) cmp lc($md65players{$b}->{name}) } @dv_zero_games;

foreach my $p (@dv_with_games, @dv_zero_games) {
    print $dv join(",",
        ucfirst($md65players{$p}->{name}),
        sprintf("%.5f",$md65players{$p}->{rank}),
        $md65players{$p}->{games},
        $md65players{$p}->{won},
        $md65players{$p}->{lost},
        sprintf("%.5f",$md65players{$p}->{pct}),
        sprintf("%.5f",$md65players{$p}->{dev}),
        sprintf("%.5f",$md65players{$p}->{orig}),
        $md65players{$p}->{gender},
	$md65players{$p}->{age}
    )."\n";
}
close($dv);

close($logfh);
