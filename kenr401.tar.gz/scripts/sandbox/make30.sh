#!/bin/bash

# Usage: ./make30.sh today.txt
# today.txt = exactly 4 lines, one player name per line
# this creates a results file, eventually, the is 2-1 for everyone
# and player 1 is 3-0.
# player 2 loses 2,3
# player 3 loses 1,3
# player 4 loses 1,2
#
# you just have to get them in the right order....



infile="$1"
outfile="o30results.txt"


# Read 4 names
mapfile -t names < "$infile"

# Safety check
if [ "${#names[@]}" -ne 4 ]; then
    echo "Input file must contain exactly 4 names (one per line)."
    exit 1
fi

n1="${names[0]}"
n2="${names[1]}"
n3="${names[2]}"
n4="${names[3]}"

# Build batch file
{
    echo "n,$n1,$n2,$n3,$n4,1"
    echo "n,$n1,$n3,$n2,$n4,1"
    echo "n,$n1,$n4,$n2,$n3,1"
} > "$outfile"

echo "Created $outfile:"
cat "$outfile"
