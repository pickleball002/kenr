#!/usr/bin/perl
#
# kcs Dec 2025
# V1 variables + gender field (9th)
#
# 40 divisors.   search for '40'.  adjust up to lessen all numbers
# 33 games before halving result
# 55 ratio   teams favored by .75 or more get good bump
# 51 games for all total sets RelFlag (reliability)


use strict;
use warnings;
use POSIX qw(strftime);

my $mdplayers_file = 'mdplayers';
my $backup_file  = 'backupmdplayers';
my $log_file     = 'mdlogging';

# ---------------------------------------------------------
# Logging setup
# ---------------------------------------------------------
open(my $logfh, ">>", $log_file) or die "Cannot open log file '$log_file': $!";

sub logprint {
    my ($msg) = @_;
    print $msg;
    print $logfh $msg;
}

# ---------------------------------------------------------
# Timestamp
# ---------------------------------------------------------
my $timestamp = strftime("%Y-%m-%d %H:%M:%S", localtime);
logprint("\n=== Script Run: $timestamp ===\n");

# ---------------------------------------------------------
# Grand Prix Flag Prompt
# ---------------------------------------------------------
logprint("\nIs this a GrandPrix event? (Y/N): ");
chomp(my $gp_input = <STDIN>);

my $grandprix = 0;

if ($gp_input =~ /^y(es)?$/i) {
    $grandprix = 1;
} elsif ($gp_input =~ /^n(o)?$/i) {
    $grandprix = 0;
} else {
    logprint("Unclear answer. Defaulting to NO.\n");
    $grandprix = 0;
}

logprint("GrandPrix flag set to: $grandprix\n");


logprint("\n=== Loading Players File ===\n");

# ---------------------------------------------------------
# Read mdplayers file
# ---------------------------------------------------------
open(my $pfh, "<", $mdplayers_file) or die "Cannot open '$mdplayers_file': $!";
my %mdplayers;

while (<$pfh>) {
    chomp;
    my @cols = split /,/;

    my ($name, $rank, $games, $won, $lost, $pct, $dev, $orig, $gender);

    if (@cols == 3) {
        ($name,$rank,$games) = @cols;
        ($won,$lost,$pct,$dev,$orig,$gender) = (0,0,0,0,$rank,"U");
    }
    elsif (@cols == 8) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig) = @cols;
        $gender = "U";
    }
    elsif (@cols == 9) {
        ($name,$rank,$games,$won,$lost,$pct,$dev,$orig,$gender) = @cols;
    }
    else {
        die "Invalid line in mdplayers file: $_\n";
    }

    my $key = lc $name;

    if (exists $mdplayers{$key}) {
        if ($games > $mdplayers{$key}->{games}) {
            logprint("Duplicate found for $name — keeping entry with MORE games\n");
            $mdplayers{$key} = {
                name=>$name, rank=>$rank+0, games=>$games+0,
                won=>$won+0, lost=>$lost+0, pct=>$pct+0,
                dev=>$dev+0, orig=>$orig+0, gender=>$gender
            };
        } else {
            logprint("Duplicate found for $name — discarding entry\n");
        }
        next;
    }

    $mdplayers{$key} = {
        name=>$name, rank=>$rank+0, games=>$games+0,
        won=>$won+0, lost=>$lost+0, pct=>$pct+0,
        dev=>$dev+0, orig=>$orig+0, gender=>$gender
    };

    logprint("Loaded: $name  rank=$rank  games=$games  won=$won lost=$lost gender=$gender\n");
}
close($pfh);

# Resolve Brian Bryan

sub normalize_name {
    my ($name) = @_;
    $name = lc $name;

    # Normalize common vowel variations
    $name =~ s/ie/y/g;     # brianie → bryany
    $name =~ s/ai/ay/g;    # kaitlyn → kaytlyn
    $name =~ tr/iy/y/;     # i and y treated same

    return $name;
}


# ---------------------------------------------------------
# Resolve name (exact or fuzzy)
# ---------------------------------------------------------

sub resolve_name {
    my ($input) = @_;
    my $key = lc $input;

    # Exact match?
    return $key if exists $mdplayers{$key};

    my @candidates;

# new prefix block

# Prefix fuzzy match (3 chars, phonetic aware)
if (length($key) >= 3) {

    my $norm_key = normalize_name($key);
    my $prefix = substr($norm_key, 0, 3);

    foreach my $p (keys %mdplayers) {

        my $norm_p = normalize_name($p);

        push @candidates, $mdplayers{$p}->{name}
            if substr($norm_p, 0, 3) eq $prefix;
    }
}

# new candidates

# If no prefix matches, try substring matches anywhere (phonetic aware)
if (!@candidates && length($key) >= 3) {

    my $norm_key = normalize_name($key);

    foreach my $p (keys %mdplayers) {

        my $norm_p = normalize_name($p);

        push @candidates, $mdplayers{$p}->{name}
            if index($norm_p, $norm_key) != -1;
    }
}


    # Still no matches
    return undef unless @candidates;

    # One match → auto-use
    if (@candidates == 1) {
        logprint("No exact match for '$input'. Using close match: $candidates[0]\n");
        return lc $candidates[0];
    }

    # Multiple matches → prompt
    logprint("\nNo exact match for '$input'. Possible matches:\n");
    for my $i (0 .. $#candidates) {
        logprint("  ".($i+1).") $candidates[$i]\n");
    }

    logprint("Select a number: ");
    chomp(my $choice = <STDIN>);

    if ($choice =~ /^\d+$/ && $choice >= 1 && $choice <= @candidates) {
        return lc $candidates[$choice-1];
    }

    logprint("Invalid choice.\n");
    return undef;
}



# ---------------------------------------------------------
# Backup file
# ---------------------------------------------------------
logprint("\n=== Creating Backup File: $backup_file ===\n");
open(my $bkp, ">", $backup_file) or die "Cannot write '$backup_file': $!";
open($pfh, "<", $mdplayers_file);
print $bkp $_ for (<$pfh>);
close($pfh);
close($bkp);

# ---------------------------------------------------------
# Input
# ---------------------------------------------------------
logprint("\n=== First Pair Input ===\n");
logprint("Enter first name: ");
chomp(my $n1in=<STDIN>);
my $n1=resolve_name($n1in)||die;

logprint("Enter second name: ");
chomp(my $n2in=<STDIN>);
my $n2=resolve_name($n2in)||die;

my $rank1=$mdplayers{$n1}->{rank};
my $rank2=$mdplayers{$n2}->{rank};

logprint("Player 1: $mdplayers{$n1}->{name}, rank = $rank1\n");
logprint("Player 2: $mdplayers{$n2}->{name}, rank = $rank2\n");

logprint("Winner Pair Total Rank = ".($rank1+$rank2)."\n");

logprint("\n=== Second Pair Input ===\n");
logprint("Enter third name: ");
chomp(my $n3in=<STDIN>);
my $n3=resolve_name($n3in)||die;

logprint("Enter fourth name: ");
chomp(my $n4in=<STDIN>);
my $n4=resolve_name($n4in)||die;

my $rank3=$mdplayers{$n3}->{rank};
my $rank4=$mdplayers{$n4}->{rank};

logprint("Player 3: $mdplayers{$n3}->{name}, rank = $rank3\n");
logprint("Player 4: $mdplayers{$n4}->{name}, rank = $rank4\n");
logprint("Opponent Pair Total Rank = ".($rank3+$rank4)."\n");



# ---------------------------------------------------------
# Reliability Flag (All Players Experienced)
# ---------------------------------------------------------
my $relflag = 0;

if (
    $mdplayers{$n1}->{games} > 51 &&
    $mdplayers{$n2}->{games} > 51 &&
    $mdplayers{$n3}->{games} > 51 &&
    $mdplayers{$n4}->{games} > 51
) {
    $relflag = 1;
}

logprint(
    "Games played: " .
    "$n1=$mdplayers{$n1}->{games}, " .
    "$n2=$mdplayers{$n2}->{games}, " .
    "$n3=$mdplayers{$n3}->{games}, " .
    "$n4=$mdplayers{$n4}->{games} . " .
    "RelFlag=$relflag\n"
);

# ---------------------------------------------------------
# Mens Match Detection
# ---------------------------------------------------------
my $g1 = lc $mdplayers{$n1}->{gender};
my $g2 = lc $mdplayers{$n2}->{gender};
my $g3 = lc $mdplayers{$n3}->{gender};
my $g4 = lc $mdplayers{$n4}->{gender};

my $pair1_mens = (($g1 eq "m" && $g2 eq "m") && ($g1 eq "m" && $g2 eq "m"));
my $pair2_mens = (($g3 eq "m" && $g4 eq "m")  && ($g3 eq "m" && $g4 eq "m"));

my $mensmatch = ($pair1_mens && $pair2_mens) ? 1 : 0;

if ($mensmatch) {
    logprint("\n*** MENS MATCH DETECTED ***\n");
} else {
    logprint("\nOpponents were NOT mens — aborting! No rank updates applied.\n");
    exit;   # ← stops script immediately
}

# ---------------------------------------------------------
# Ratio calc
# ---------------------------------------------------------
logprint("\n=== Ratio Calculation ===\n");

my $winner_rank=$rank1 + $rank2;
my $opponent_rank=$rank3 + $rank4;

my $ratio = $winner_rank / $opponent_rank;

if ($winner_rank >= $opponent_rank + 0.75) { $ratio += 0.55; }
elsif ($winner_rank <= $opponent_rank - 0.75) { $ratio -= 0.55; }

if ($ratio != 1) {
    $ratio = 1/$ratio;
    logprint("Ratio inverted → $ratio\n");
} else {
    logprint("Ratio = $ratio\n");
}

# ---------------------------------------------------------
# Games divisor + final adjusted
# ---------------------------------------------------------
logprint("\nWas this 1, 2, or 3 games? ");
chomp(my $gamesplayed=<STDIN>);

# grandprix doubles with 20 over 40
#my $divisor = ($gamesplayed==2)?40:80;
#my $final_adjusted_value = $ratio/$divisor;

# ---------------------------------------------------------
# Games divisor + final adjusted (GrandPrix aware)
# ---------------------------------------------------------

my ($gp_one, $gp_two, $gp_three);

if ($grandprix) {
    # Grand Prix mode → smaller divisors
    $gp_one   = 53;
    $gp_two   = 24;
    $gp_three = 48;
} else {
    # Standard mode
    $gp_one   = 106;
    $gp_two   = 48;
    $gp_three = 96;
}
my $divisor;

if ($gamesplayed == 1) {
    $divisor = $gp_one;
}
elsif ($gamesplayed == 2) {
    $divisor = $gp_two;
}
elsif ($gamesplayed == 3) {
    $divisor = $gp_three;
}
else {
    die "Invalid gamesplayed value: $gamesplayed\n";
}

my $final_adjusted_value = $ratio / $divisor;

logprint("GrandPrix=$grandprix | Games=$gamesplayed | Divisor=$divisor\n");
logprint("Final adjusted value = $final_adjusted_value\n");


# ---------------------------------------------------------
# Rank update helper
# ---------------------------------------------------------
sub update_rank {
    my ($key,$val)=@_;
    my $adj=$val;
    $adj*=2 if $mdplayers{$key}->{games} < 30;
    $mdplayers{$key}->{rank}+=$adj;
}

update_rank($n1, $final_adjusted_value);
update_rank($n2, $final_adjusted_value);
update_rank($n3,-$final_adjusted_value);
update_rank($n4,-$final_adjusted_value);

# ---------------------------------------------------------
# Games played
# ---------------------------------------------------------
$mdplayers{$_}->{games}+=$gamesplayed for ($n1,$n2,$n3,$n4);


# ---------------------------------------------------------
# Replay recap (logging file ONLY)
# ---------------------------------------------------------
my ($date_only) = split / /, $timestamp;

print $logfh join(" ",
    "replayrecap",
    $date_only,
    $mdplayers{$n1}->{name},
    $mdplayers{$n2}->{name},
    "/",
    $mdplayers{$n3}->{name},
    $mdplayers{$n4}->{name},
    "games=$gamesplayed"
) . "\n";

# ---------------------------------------------------------
# Games Won/Lost
# ---------------------------------------------------------
if ($gamesplayed == 1) {
    $mdplayers{$n1}->{won} += 1; $mdplayers{$n2}->{won} += 1;
    $mdplayers{$n3}->{lost} += 1; $mdplayers{$n4}->{lost} += 1;
}
elsif ($gamesplayed == 2) {
    $mdplayers{$n1}->{won} += 2; $mdplayers{$n2}->{won} += 2;
    $mdplayers{$n3}->{lost} += 2; $mdplayers{$n4}->{lost} += 2;
}
elsif ($gamesplayed == 3) {
    $mdplayers{$n1}->{won} += 2; $mdplayers{$n1}->{lost} += 1;
    $mdplayers{$n2}->{won} += 2; $mdplayers{$n2}->{lost} += 1;

    $mdplayers{$n3}->{won} += 1; $mdplayers{$n3}->{lost} += 2;
    $mdplayers{$n4}->{won} += 1; $mdplayers{$n4}->{lost} += 2;
}

# ---------------------------------------------------------
# pct & deviation
# ---------------------------------------------------------
foreach my $p (keys %mdplayers) {
    my $w = $mdplayers{$p}->{won};
    my $l = $mdplayers{$p}->{lost};

    if ($w + $l > 0) {
        $mdplayers{$p}->{pct} = $w / ($w + $l);
    } else {
        $mdplayers{$p}->{pct} = 0;
    }

    $mdplayers{$p}->{dev} = $mdplayers{$p}->{rank} - $mdplayers{$p}->{orig};
}

# ---------------------------------------------------------
# Write mdplayers file
# ---------------------------------------------------------
logprint("\n=== Writing Updated Players File ===\n");

open(my $out, ">", $mdplayers_file) or die;

my @with_games = grep { $mdplayers{$_}->{games} > 0 } keys %mdplayers;
my @zero_games = grep { $mdplayers{$_}->{games} == 0 } keys %mdplayers;

@with_games = sort { $mdplayers{$b}->{rank} <=> $mdplayers{$a}->{rank} } @with_games;
@zero_games = sort { lc($mdplayers{$a}->{name}) cmp lc($mdplayers{$b}->{name}) } @zero_games;

foreach my $p (@with_games, @zero_games) {
    print $out join(",",
        ucfirst($mdplayers{$p}->{name}),
        sprintf("%.5f",$mdplayers{$p}->{rank}),
        $mdplayers{$p}->{games},
        $mdplayers{$p}->{won},
        $mdplayers{$p}->{lost},
        sprintf("%.5f",$mdplayers{$p}->{pct}),
        sprintf("%.5f",$mdplayers{$p}->{dev}),
        sprintf("%.5f",$mdplayers{$p}->{orig}),
        $mdplayers{$p}->{gender}
    )."\n";
}

close($out);

logprint("\n=== Update Complete ===\n");
logprint("Version 3.0 — batch processing\n");

# ---------------------------------------------------------
# Write winningpercentage file
# ---------------------------------------------------------
logprint("\n=== Writing mdwinningpercentage File ===\n");

open(my $wp, ">", "mdwinningpercentage") or die "Cannot write mdwinningpercentage: $!";

my @wp_with_games = grep { $mdplayers{$_}->{games} > 0 } keys %mdplayers;
my @wp_zero_games = grep { $mdplayers{$_}->{games} == 0 } keys %mdplayers;

@wp_with_games = sort { $mdplayers{$b}->{pct} <=> $mdplayers{$a}->{pct} } @wp_with_games;
@wp_zero_games = sort { lc($mdplayers{$a}->{name}) cmp lc($mdplayers{$b}->{name}) } @wp_zero_games;

foreach my $p (@wp_with_games, @wp_zero_games) {
    print $wp join(",",
        ucfirst($mdplayers{$p}->{name}),
        sprintf("%.5f",$mdplayers{$p}->{rank}),
        $mdplayers{$p}->{games},
        $mdplayers{$p}->{won},
        $mdplayers{$p}->{lost},
        sprintf("%.5f",$mdplayers{$p}->{pct}),
        sprintf("%.5f",$mdplayers{$p}->{dev}),
        sprintf("%.5f",$mdplayers{$p}->{orig}),
        $mdplayers{$p}->{gender}
    )."\n";
}
close($wp);

# ---------------------------------------------------------
# Write deviation file
# ---------------------------------------------------------
logprint("\n=== Writing deviation File ===\n");

open(my $dv, ">", "mddeviation") or die "Cannot write mddeviation: $!";

my @dv_with_games = grep { $mdplayers{$_}->{games} > 0 } keys %mdplayers;
my @dv_zero_games = grep { $mdplayers{$_}->{games} == 0 } keys %mdplayers;

@dv_with_games = sort { $mdplayers{$b}->{dev} <=> $mdplayers{$a}->{dev} } @dv_with_games;
@dv_zero_games = sort { lc($mdplayers{$a}->{name}) cmp lc($mdplayers{$b}->{name}) } @dv_zero_games;

foreach my $p (@dv_with_games, @dv_zero_games) {
    print $dv join(",",
        ucfirst($mdplayers{$p}->{name}),
        sprintf("%.5f",$mdplayers{$p}->{rank}),
        $mdplayers{$p}->{games},
        $mdplayers{$p}->{won},
        $mdplayers{$p}->{lost},
        sprintf("%.5f",$mdplayers{$p}->{pct}),
        sprintf("%.5f",$mdplayers{$p}->{dev}),
        sprintf("%.5f",$mdplayers{$p}->{orig}),
        $mdplayers{$p}->{gender}
    )."\n";
}
close($dv);

close($logfh);
